const express = require('express');
const app = express();
const fs = require('fs');
const excel = require('exceljs');
const bodyParser = require('body-parser');
const cors = require('cors');
app.use(cors());

const XLSX = require('xlsx');

app.use(bodyParser.json());


app.use(express.static(__dirname + '/dist/excel-qa-app'));


app.get('/api/fetch-questions', (req, res) => {
  const workbook = new excel.Workbook();
  workbook.xlsx.readFile('DATA.xlsx') 
    .then(() => {
      const worksheet = workbook.getWorksheet('DATA'); 

      const questions = [];
      worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {
        const question = row.getCell(1).value;
        const answer = row.getCell(2).value;

        if (!answer) {
          questions.push({ question });
        }
      });

      res.json(questions);
    })
    .catch(err => {
      console.error(err);
      res.status(500).json({ error: 'Failed to fetch questions' });
    });
});


app.post('/api/submit-answer', (req, res) => {
  const { question, answer } = req.body;
  console.log('Received POST request to /api/submit-answer');
  console.log('Received answer from client:', { question, answer });
  

 
  const workbook = new excel.Workbook();
  workbook.xlsx.readFile('DATA.xlsx') 
    .then(() => {
      const worksheet = workbook.getWorksheet('DATA'); 
      
      let found = false;
      worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {
        const rowQuestion = row.getCell(1).value;
        console.log(`Question from request: ${question}`);
        console.log(`Question from Excel: ${rowQuestion}`);
        console.log('hi');

        if (rowQuestion === question) {
         
          row.getCell(2).value = answer;
          found = true;
        }
      });

      if (found) {
      
        return workbook.xlsx.writeFile('DATA.xlsx');
      } else {
        console.log('hi')
        return Promise.reject('Question not found'); 
      }
    })
    .then(() => {
      res.json({ message: 'Answer submitted successfully' });
    })
    .catch(err => {
      console.error(err);
      res.status(500).json({ error: 'Failed to submit answer' });
    });
});


const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});


// excel fetch function

app.get('/api/fetch-excel-data', (req, res) => {
  
  const workbook = new excel.Workbook();
  workbook.xlsx.readFile('DATA.xlsx')
    .then(() => {
    
      const worksheet = workbook.getWorksheet('DATA'); 

      
      const excelData = [];
      worksheet.eachRow((row) => {
        excelData.push({
          column1: row.getCell(1).value,
          column2: row.getCell(2).value,
       
        });
      });

  
      res.json(excelData);
    })
    .catch((err) => {
      console.error(err);
      res.status(500).json({ error: 'Failed to read Excel data' });
    });
});
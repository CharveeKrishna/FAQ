import { Component, Input, Output, EventEmitter } from '@angular/core';



@Component({
  selector: 'app-answer-comment',
  templateUrl: './answer-comment.component.html',
  styleUrls: ['./answer-comment.component.css']
})
export class AnswerCommentComponent {
  @Input() question: string = '';
  @Input() answer: string = '';

  @Output() onSubmit: EventEmitter<string> = new EventEmitter<string>();

  submitAnswer() {
    
    this.onSubmit.emit(this.answer);

    
    this.answer = '';
  }
}

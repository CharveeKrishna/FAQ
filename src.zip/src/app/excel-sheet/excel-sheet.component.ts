import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface QuestionWithAnswer {
  question: string;
  answer: string;
}

@Component({
  selector: 'app-excel-sheet',
  templateUrl: './excel-sheet.component.html',
  styleUrls: ['./excel-sheet.component.css'],
})
export class ExcelSheetComponent implements OnInit {
  answeredQuestions: QuestionWithAnswer[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // Make an HTTP GET request to fetch answered questions
    this.http
      .get<QuestionWithAnswer[]>('http://localhost:3001/api/fetch-excel-data')
      .subscribe(
        (data) => {
          // Filter questions with answers and remove unwanted lines
          this.answeredQuestions = data.filter(
            (item) =>
              item.answer.trim() !== '' &&
              item.question.trim() !== 'question' &&
              item.answer.trim() !== 'answer'
          );
        },
        (error) => {
          console.error('Error fetching answered questions:', error);
        }
      );
  }
}

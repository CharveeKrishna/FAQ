import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QuestionListComponent } from './question-list/question-list.component';
import { AnswerCommentComponent } from './answer-comment/answer-comment.component';
import { ExcelSheetComponent } from './excel-sheet/excel-sheet.component';

@NgModule({
  declarations: [
    AppComponent,
    QuestionListComponent,
    AnswerCommentComponent,
    ExcelSheetComponent
  ],
  imports: [
    HttpClientModule,
    FormsModule,
    BrowserModule,
    RouterModule.forRoot([
      
      { path: 'questions', component: QuestionListComponent },
      { path: 'excel-sheet', component: ExcelSheetComponent },

    ])             
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

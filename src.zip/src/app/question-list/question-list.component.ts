import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observer } from 'rxjs';

interface Question {
  question: string;
}

@Component({
  selector: 'app-question-list',
  templateUrl: './question-list.component.html',
  styleUrls: ['./question-list.component.css'],
})
export class QuestionListComponent implements OnInit {
  questions: Question[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
  
    this.http.get<Question[]>('http://localhost:3001/api/fetch-questions').subscribe({
      next: (data) => {
        this.questions = data;
        console.log(data);
      },
      error: (error) => {
        console.error(error);
      },
    } as Observer<Question[]>);
  }

  submitAnswer(question: string, answer: string) {
    
    if (!question) {
      console.error('No question selected.');
      return;
    }
  
    if (!answer) {
      console.error('No answer provided.');
      return;
    }
  
    console.log('Sending answer to server:', { question, answer });
  
    this.http.post<any>('http://localhost:3001/api/submit-answer', { question, answer })
      .subscribe({
        next: (response) => {
         
          console.log(response);
          console.log('Submitting answer to:', 'http://localhost:3001/api/submit-answer');
          console.log('Request payload:', { question, answer });
  
          
        
        },
        error: (error) => {
       
          console.error(error);
        }
      });
      this.removeQuestion(question);
       alert('Answer saved');
  }

  private removeQuestion(question: string) {
    const index = this.questions.findIndex((q) => q.question === question);
    if (index !== -1) {
      this.questions.splice(index, 1);
    }
  }
  
}
